import serial

# Define the serial port and baud rate
serial_port = 'COM1'  # Replace with your serial port name (e.g., 'COM1' on Windows)
baud_rate = 9600  # Set the appropriate baud rate for your device

try:
    # Open the serial connection
    ser = serial.Serial(serial_port, baud_rate)
    
    # Print a message to indicate that the connection is open
    print(f"Serial connection opened on {serial_port} at {baud_rate} baud.")
    
    # You can now send and receive data through the 'ser' object
    # For example, to send data:
    # ser.write(b'Hello, Arduino!')
    
    # To receive data:
    # received_data = ser.readline()
    # print("Received:", received_data.decode())
    
    # Don't forget to close the serial connection when done
    ser.close()
    print("Serial connection closed.")

except serial.SerialException as e:
    print(f"Error: {e}")
