import browser_cookie3

# URL you want to access
url = 'https://bard.google.com/'

# Use browser_cookie3 to get cookies from your browser (e.g., Chrome)
cj = browser_cookie3.chrome()

# Find the "__Secure-1PSID" cookie
secure_1psid_cookie = None

for cookie in cj:
    if cookie.name == '__Secure-1PSID':
        secure_1psid_cookie = cookie.value
        break

# Check if the "__Secure-1PSID" cookie was found
if secure_1psid_cookie:
    print(secure_1psid_cookie)
else:
    print("The __Secure-1PSID cookie was not found.")

